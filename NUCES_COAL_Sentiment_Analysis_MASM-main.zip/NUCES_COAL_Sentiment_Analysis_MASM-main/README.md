# Sentiment_Analysis_using_Microsoft_MacroAssembler
Assembly Language Version of Machine Learning Software for emotional analysis of Customer-Reviews 
