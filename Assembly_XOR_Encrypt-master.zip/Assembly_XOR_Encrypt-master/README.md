# Assembly_XOR_Encrypt
XOR Encryption/Decryption for Text Files
# To Do:
 * Binary File Support
 * Binary to Text File Conversion
 * Better encryption key (single character is lame)
 * Basic Console File Editing (READ, APPEND, WRITE, CREATE)
 * Become dependent from the Irvine library
 
# Screenshots:
![01](https://user-images.githubusercontent.com/15623775/31103415-cd5695de-a7a4-11e7-90b3-8758950e8b71.PNG)
![02](https://user-images.githubusercontent.com/15623775/31103419-cf1bf42c-a7a4-11e7-8d73-a2454d67f841.PNG)
![03](https://user-images.githubusercontent.com/15623775/31103421-d03f8e68-a7a4-11e7-8e36-6158a5cbf958.PNG)
