# Sudoku
A desktop Sudoku game built with Assembly programming language.

The main and only folder in this repository is "Assembly_project" which is a visual studio project having the project source code under "main.asm" file.
