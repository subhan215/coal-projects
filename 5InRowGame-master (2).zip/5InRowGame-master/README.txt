5InRowGame
in this game there are 2 players.
each player can choose one of the characters X or O in his turn. 
the player who create or build a sequence of the same Character with length 5 who is the winner.
there are 3 cases for win :
(1) row (2) column (3) diagonal

if you enter an index to row or column that is out of board size you get message error
also if you insert a Character that is not O Or X you get error message
and if you enter a charater in used place you get error message

the game is generic you can change the board size or the sequence length for winning 

to play the game just download 5InrowGame.exe

 